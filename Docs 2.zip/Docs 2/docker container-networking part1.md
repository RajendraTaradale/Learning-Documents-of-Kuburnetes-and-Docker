https://docs.docker.com/engine/userguide/networking/default_network/dockerlinks/

https://docs.docker.com/engine/userguide/networking/

Before the Docker networks feature, you could use the Docker link feature to allow containers to discover each other and securely transfer information about one container to another container. With the introduction of the Docker networks feature, you can still create links but they behave differently between default bridge network and user defined networks.

This section briefly discusses connecting via a network port and then goes into detail on container linking in default bridge network.

Network poort mapping

Connect using network port mapping 

docker run -d -P training/webapp python app.py

Note: Containers have an internal network and an IP address. Docker can have a variety of network configurations. You can see more information on Docker networking here.
When that container was created, the -P flag was used to automatically map any network port inside it to a random high port within an ephemeral port range on your Docker host. Next, when docker ps was run, you saw that port 5000 in the container was bound to port 49155 on the host.

docker run -d -p 80:5000 training/webapp python app.py

This  constrains to only one container on that specific port.
Instead, you may specify a range of host ports to bind a container port to that is different than the default ephemeral port range:

docker run -d -p 8000-9000:5000 training/webapp python app.py

This would bind port 5000 in the container to a randomly available port between 8000 and 9000 on the host.

By default the -p flag will bind the specified port to all interfaces on the host machine. But you can also specify a binding to a specific interface, for example only to the localhost.

docker run -d -p 127.0.0.1:80:5000 training/webapp python app.py

This would bind port 5000 inside the container to port 80 on the localhost or 127.0.0.1 interface on the host machine.

to bind port 5000 of the container to a dynamic port but only on the localhost, you could use:

docker run -d -p 127.0.0.1::5000 training/webapp python app.py
 
Also bind UDP ports by adding a trailing /udp. For example:


docker run -d -p 127.0.0.1:80:5000/udp training/webapp python app.py

The useful docker port shortcut which showed us the current port bindings. This is also useful for showing you specific port configurations. For example, if you�ve bound the container port to the localhost on the host machine, then the docker port output will reflect that.

docker port container-id 5000

127.0.0.1:49155
The -p flag can be used multiple times to configure multiple ports.


The --link flag is a deprecated legacy feature of Docker. It may eventually be removed. Unless you absolutely need to continue using it, we recommend that you use user-defined networks to facilitate communication between two containers instead of using --link. One feature that user-defined networks do not support that you can do with --link is sharing environmental variables between containers. However, you can use other mechanisms such as volumes to share environment variables between containers in a more controlled way.

The link option for containers, not working  with non-root container user processes.

 Connect with the linking system

Note: This section covers the legacy link feature in the default bridge network. Please refer to linking containers in user-defined networks for more information on links in user-defined networks.
Network port mappings are not the only way Docker containers can connect to one another. Docker also has a linking system that allows you to link multiple containers together and send connection information from one to another. When containers are linked, information about a source container can be sent to a recipient container. This allows the recipient to see selected data describing aspects of the source container.


